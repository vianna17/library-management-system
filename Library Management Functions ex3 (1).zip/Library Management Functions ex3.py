def Display(book_info):
    
    for i in book_info:
        
        book_detail=i.split(',')
        print (book_detail[2], end='')
        print (book_detail[1], end='')
        print (book_detail[3], end='')
        print (book_detail[4].replace("\n", ""), end='')
        print (' '+book_detail[0])
       
        
        

def Adding(book_info):

    all_ISBN=[]
    book_detail=''
    
    for i in book_info:
        
        book_detail=i.split(',')
        all_ISBN.append(book_detail[3].replace(" ", ""))

    ISBN=input("Enter a book ISBN: ")

    for i in book_info:
        
        book_detail=i.split(',')
        if (book_detail[3].replace(" ", ""))==ISBN:
            print(i)
  

    if ISBN in all_ISBN:
        print('Already present')
    else:  
        book_title=input("Enter the book title: ")
        publication_date=input("Enter the Publication Date: ")
        access=input("Enter access: ")
        author_last_name=input("Enter the author last name: ")
        
        book_detail=access+', '+book_title+', '+author_last_name+', '+ISBN+', '+publication_date+'\n'
        book_info.append(book_detail)

    print(book_info)
    

    
def searching(book_info):

    ISBN=input("Enter a book ISBN: ")
    

    for i in book_info:
        book_detail=i.split(',')

        if (book_detail[3].replace(" ", ""))==(ISBN):
            print(i)


    


def updating(book_info):
    

    ISBN=input("Enter a book ISBN: ")

    for i in book_info:
        book_detail=i.split(',')

        if (book_detail[3].replace(" ", ""))==(ISBN):
       
            if book_detail[0] == '0':
                print("Book details cannot be updated.")
            else:
                print("Enter updated details:")





                
test = open("test.txt", "r")
book_info=[]
lines = test.readlines()

for line in lines:
    book_info.append(line)

test.close()

Display(book_info)    
Adding(book_info)
searching(book_info)
updating(book_info)



    

    


    
            

        
        
       
            
    



